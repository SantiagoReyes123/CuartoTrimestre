
package app;

import java.util.ArrayList;
import java.util.List;


public class Vehiculo {
       private String placa;
    private String marca;
    private String modelo;
    private List<Reparacion> listaReparaciones;

    public Vehiculo(String placa, String marca, String modelo) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.listaReparaciones = new ArrayList<>();
    }

    public String getPlaca() {
        return placa;
    }

    public void agregarReparacion(Reparacion reparacion) {
        listaReparaciones.add(reparacion);
    }
}
