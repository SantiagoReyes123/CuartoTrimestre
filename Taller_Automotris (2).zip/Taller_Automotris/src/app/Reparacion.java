
package app;

import java.util.ArrayList;
import java.util.List;

public class Reparacion {
     private int id;
    private Vehiculo vehiculo;
    private List<Repuesto> listaRepuestosUtilizados;
    private String estado;

    public Reparacion(int id, Vehiculo vehiculo) {
        this.id = id;
        this.vehiculo = vehiculo;
        this.listaRepuestosUtilizados = new ArrayList<>();
        this.estado = "pendiente";
    }
      public void agregarRepuesto(Repuesto repuesto) {
        listaRepuestosUtilizados.add(repuesto);
    }

    public void completarReparacion() {
        this.estado = "completada";
    }
}
