package app;

import javax.swing.*;

public class Principal {
  public static void main(String[] args) {
        Taller taller = new Taller();
        
        boolean continuar = true;        
        while (continuar) {
            String[] opciones = {
                "Agregar repuesto",
                "Registrar vehículo",
                "Asignar reparación",
                "Buscar repuesto",
                "Salir"
            };
            
            String seleccion = (String) JOptionPane.showInputDialog(null, "Selecciona una opción:",
                    "Gestión Taller Automotriz", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
            
            switch (seleccion) {
                case "Agregar repuesto":
                    taller.agregarRepuesto();
                    break;
                    
                case "Registrar vehículo":
                    taller.registrarVehiculo();
                    break;
                    
                case "Asignar reparación":
                    taller.asignarReparacion();
                    break;
                    
                case "Buscar repuesto":
                    
                    String idRepuestoStr = JOptionPane.showInputDialog("Ingrese el ID del repuesto a buscar");
                    Repuesto repuesto = taller.buscarRepuesto(Integer.parseInt(idRepuestoStr));
                    if (repuesto != null) {
                        JOptionPane.showMessageDialog(null, "Repuesto encontrado: " + repuesto.getNombre());
                    } else {
                        JOptionPane.showMessageDialog(null, "Repuesto no encontrado");
                    }
                    break;

                case "Salir":
                    continuar = false;
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida");
            }
        }
    }
}
