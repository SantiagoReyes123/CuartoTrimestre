
package app;


public class Repuesto {
        private int id;
    private String nombre;
    private int cantidadDisponible;
    private double precio;

    public Repuesto(int id, String nombre, int cantidadDisponible, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.cantidadDisponible = cantidadDisponible;
        this.precio = precio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    public void reducirStock(int cantidad) {
        this.cantidadDisponible -= cantidad;
    }

    public boolean tieneStock(int cantidad) {
        return cantidadDisponible >= cantidad;
    }
}
