package app;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

public class Taller {
    private int id;
    private String nombre;
    private int cantidadDisponible;
    private double precio;
    
    private List<Repuesto> listaRepuestos;
    private List<Vehiculo> listaVehiculos;
    private List<Reparacion> listaReparaciones;

    public Taller() {
        this.listaRepuestos = new ArrayList<>();
        this.listaVehiculos = new ArrayList<>();
        this.listaReparaciones = new ArrayList<>();
    }

    public void agregarRepuesto() {
        int idRepuesto = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del repuesto"));
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del repuesto");
        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad disponible"));
        double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del repuesto"));

        Repuesto repuesto = new Repuesto(idRepuesto, nombre, cantidad, precio);
        listaRepuestos.add(repuesto);
        JOptionPane.showMessageDialog(null, "Repuesto agregado");
        guardarInventario();
    }

    public void registrarVehiculo() {
        String placa = JOptionPane.showInputDialog("Ingrese la placa del vehículo");
        String marca = JOptionPane.showInputDialog("Ingrese la marca del vehículo");
        String modelo = JOptionPane.showInputDialog("Ingrese el modelo del vehículo");

        Vehiculo vehiculo = new Vehiculo(placa, marca, modelo);
        listaVehiculos.add(vehiculo);
        JOptionPane.showMessageDialog(null, "Vehículo registrado");
    }

    public void asignarReparacion() {
        int idReparacion = listaReparaciones.size() + 1; // Generar un nuevo ID
        String placa = JOptionPane.showInputDialog("Ingrese la placa del vehículo");
        Vehiculo vehiculo = buscarVehiculo(placa);

        if (vehiculo == null) {
            JOptionPane.showMessageDialog(null, "Vehículo no encontrado");
            return;
        }

        Reparacion reparacion = new Reparacion(idReparacion, vehiculo);
        listaReparaciones.add(reparacion);

        String idRepuestoStr = JOptionPane.showInputDialog("Ingrese el ID del repuesto a utilizar");
        Repuesto repuesto = buscarRepuesto(Integer.parseInt(idRepuestoStr));

        if (repuesto != null && repuesto.tieneStock(1)) {
            reparacion.agregarRepuesto(repuesto);
            repuesto.reducirStock(1);
            JOptionPane.showMessageDialog(null, "Reparación asignada");
        } else {
            JOptionPane.showMessageDialog(null, "Repuesto no disponible o agotado");
        }
    }
public Repuesto buscarRepuesto(int idRepuesto) {
        return listaRepuestos.stream()
                .filter(r -> r.getId() == idRepuesto)
                .findFirst()
                .orElse(null);
    }


    private Vehiculo buscarVehiculo(String placa) {
        return listaVehiculos.stream()
                .filter(v -> v.getPlaca().equalsIgnoreCase(placa))
                .findFirst()
                .orElse(null);
    }

    public void guardarInventario() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("InventarioRepuestos.txt", true))) {
            for (Repuesto repuesto : listaRepuestos) {
                writer.write("ID: " + repuesto.getId() + ", Nombre: " + repuesto.getNombre() + 
                             ", Cantidad: " + repuesto.getCantidadDisponible() + ", Precio: " + repuesto.getPrecio());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void cargarInventario() {
        // Método para cargar inventario desde un archivo (implementación necesaria)
    }

    // Método para manejar reparaciones concurrentes con hilos
//    public void ejecutarReparacion(Reparacion reparacion) {
//        new Thread(() -> {
//            try {
//                // Simulamos tiempo de reparación
//                Thread.sleep(2000);
//                reparacion.completarReparacion();
//                JOptionPane.showMessageDialog(null, "Reparación completada para el vehículo: " + reparacion.vehiculo.getPlaca());
//             } catch (IOException e) {
//            e.printStackTrace();
//        }
//        }).start();
}


